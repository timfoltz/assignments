import React, { Component } from 'react';

class MyComps1 extends Component{
    render(){
        return(
            <div>
                This is working?
            </div>
        );
    }
}

export default MyComps1;