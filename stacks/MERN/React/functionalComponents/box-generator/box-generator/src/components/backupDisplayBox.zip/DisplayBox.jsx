import React, { useState } from 'react';

const DisplayBox = (props) => {

    console.log("PROPS",props.box)
    const [boxes, setBoxes] = useState([{}]);
    // ,{color:props.box}
    // setBoxes([...boxes, {color: "orange"}])
    
    console.log(boxes.map(color => color))
    return(
        <div style= {{display:"flex", flexWrap:"wrap"}}>{
            boxes.map( c => 
                <div className="box"style ={{margin: "10px",height:"100px",width:"100px",backgroundColor: c.color}} >{ c.color }</div>
            )
            
        }</div>

    );




};
export default DisplayBox



