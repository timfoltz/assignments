import React, { useState } from 'react';

const ColorForm = (props) => {

    const [boxes, setBoxes] = useState([{}]);
    const [ inputColor, setInputColor] = useState("")

    const addBox = (e) =>{
        e.preventDefault();
        props.addNewBox(inputColor);        
        console.log("This is the addBox function",inputColor)
    };
    // const handleChange = (e) => {
    //     setInputColor({
    //         [e.target.name]: e.target.value
    //     });
    //     console.log(inputColor)
    // }

    return(

        <form className="form-group" onSubmit={addBox}>
                <div>
                    <input  name="inputColor" type="text" onChange= { (e) => setInputColor(e.target.value) } value={inputColor}/>
                    <input type="submit" value="Add Box" />
                </div>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
                <br/>
            <div style={{color:"black"}}>
                {JSON.stringify(inputColor)}
            </div>
        </form>


    )




}
export default ColorForm