import React from 'react';
// import ViewPoke from './ViewPoke';


const PokeFetch = ({connectLink}) =>{


    return (
        <div>

            <button onClick = { connectLink }>Fetch Pokemon</button>
        </div>



    )

}
export default PokeFetch;