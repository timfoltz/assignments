import React from 'react';
import {Link} from '@reach/router';


const Word = (props) =>{






    return(

        <h2>The word is {props.word}</h2>

    )
}
export default Word