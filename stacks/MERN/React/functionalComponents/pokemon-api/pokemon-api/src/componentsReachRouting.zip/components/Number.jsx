import React from 'react';
import {Link} from '@reach/router';


const Number = (props) =>{






    return(

        <h2>The Number is  {props.id}</h2>

    )
}
export default Number