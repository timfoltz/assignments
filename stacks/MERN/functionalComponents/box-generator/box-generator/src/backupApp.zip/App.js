import './App.css';
import Form from './components/Form'
import DisplayBox from './components/DisplayBox';
import ColorForm from './components/Form';
import { useState } from 'react';



function App() {

  const [newBox, setNewBox] = useState([{}])

  const makeNewBox = (newBox) => {
    setNewBox(newBox);
    console.log("Inside the makeNewBox function",newBox)
  }
  return (
    <div className="App">
      
        <ColorForm addNewBox={ makeNewBox }/>
        
      
      <DisplayBox box ={ newBox }/>
    </div>
  );
}

export default App;
