import { useState, useEffect } from 'react';
import axios from 'axios'
import {Link} from "@reach/router"
// import '../App.css'


const Todo = ({id}) =>{

    const [todo, setTodo] = useState({
        completed: false,
        createdAt: Date.now(),
        desc: "",
        title: "",
        updatedAt: Date.now()
    });

    useEffect(()=>{
        axios.get(`http://localhost:8888/todos/${id}`)
            .then(res =>{
                console.log(res);
                setTodo(res.data)
            })
            .catch(err =>{
                console.log(err);
            })
    },[])

    return (
        <div style={{padding: "30px"}}>

            <Link className="links" to="/" >Home</Link>
            <p>{todo.title}</p>
            <p>{todo.desc}</p>
            <p><input type="checkbox" value={todo.completed}/></p>



        </div>
    )
}

export default Todo