from django.shortcuts import render, HttpResponse, redirect
from.models import Show

def root(request):
    return redirect('/shows')

def shows(request):
    
    context = {
        "shows_model" : Show.objects.all()
    }
    return render(request, "shows.html", context)

def show_info(request, num):
    context ={
        "show_model" : Show.objects.get(id=num)
    }
    return render(request, "Show_info.html", context)

def edit(request, num):
    context = {
        "show_model" : Show.objects.get(id=num)
    }
    
    return render(request, "edit.html", context)

def delete(request, num):
    this_show = Show.objects.get(id=num)
    this_show.delete()
    return redirect('/')

def add_new(request):
    return render(request, "add_new.html")

def process_new(request):
    if request.method == 'POST':
        if request.POST.get('title') and request.POST.get('network') and request.POST.get('release_date') and request.POST.get('description') :
            title = request.POST.get('title')
            network = request.POST.get('network')
            release_date = request.POST.get('release_date')
            description = request.POST.get('description')
            Show.objects.create(title=title, network=network, release_date=release_date, desc= description)
            return redirect("/")
        else:
            return redirect('/error')
    else:
        return redirect('/error')
            
    return render(request, "show_info.html")

def process_update(request, num):
    this_show = Show.objects.get(id=num)
    if request.method == 'POST':
        if request.POST.get('title') and request.POST.get('network') and request.POST.get('release_date') and request.POST.get('description') :
            title = request.POST.get('title')
            network = request.POST.get('network')
            release_date = request.POST.get('release_date')
            description = request.POST.get('description')

            this_show.title = title
            this_show.network = network
            this_show.release_date = release_date
            this_show.desc = description
            return redirect(f"/show_info/{num}")
        else:
            return redirect('/error')
    else:
        return redirect('/error')
            


def error(request):
    return HttpResponse('Please try again')

# Create your views here.
